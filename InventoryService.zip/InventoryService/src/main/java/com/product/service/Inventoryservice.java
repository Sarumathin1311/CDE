package com.product.service;

import java.util.Optional;

import org.springframework.web.bind.annotation.PathVariable;

import com.product.model.InventoryEntity;

public interface Inventoryservice {

	public Optional<InventoryEntity> getProduct( Integer productid);
}
