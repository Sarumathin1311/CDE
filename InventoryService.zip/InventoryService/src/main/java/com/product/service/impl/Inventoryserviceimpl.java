package com.product.service.impl;

import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PathVariable;
import com.product.model.InventoryEntity;
import com.product.repository.Inventoryrepository;
import com.product.service.Inventoryservice;

@Service
public class Inventoryserviceimpl implements Inventoryservice {
	

		@Autowired
		private Inventoryrepository inventoryrepository;

		
			public Optional<InventoryEntity> getProduct( Integer productid) {
				return inventoryrepository.findById(productid);

	}
	}


